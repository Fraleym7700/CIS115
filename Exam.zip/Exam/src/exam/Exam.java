
package exam;
import java.util.Scanner;
public class Exam {
public static void main(String[] args) 
    {
        displayPseudocode();
        calculateTotal();
        displayThankYou();         
    }


    public static void displayPseudocode()
    {
        System.out.print("---------------------------------------(displayPseudocode Start)--------------------------------\n\n");
        
        System.out.print("This program will display a calculate a food total for Tacos, Drinks while applying tax\n\n");  
        
        System.out.print("=======================================(displayPseudocode End)==================================\n\n");
    }
        public static void calculateTotal()
    {
       double amountOfDrinksChosen = 0;
       double amountOfTacosChosen = 0;
       double tacoCost =  amountOfTacosChosen * 1.25;
       double drinkCost = amountOfDrinksChosen * .99;
       double TAX_RATE = 6.5;
       double subTotal = (tacoCost + drinkCost);
       double Tax = (subTotal * TAX_RATE);
       double total = (subTotal + Tax);
   
        
        
        Scanner keyboard = new Scanner(System.in);
        System.out.print("---------------------------------------(calculateTotal Start)--------------------------------\n\n");
        System.out.println("How many tacos do you want");
        amountOfTacosChosen = keyboard.nextDouble();
        System.out.println("How many drinks do you want");
        amountOfDrinksChosen = keyboard.nextDouble();
        System.out.print("***********************************************************************************************\n");
        System.out.print("Number of Tacos:\t" + amountOfTacosChosen + "\n") ;
        System.out.print("Number of Drinks:\t" + amountOfDrinksChosen + "\n") ;
        System.out.print("***********************************************************************************************\n");  
        System.out.print("Subtotal:$\t" + subTotal + "\n");
        System.out.print("Tax:$\t" + Tax + "\n");
        System.out.print("***********************************************************************************************\n");
        System.out.print("Total:$\t" + total + "\n")  ;
        System.out.print("=======================================(calculateTotal End)==================================\n\n");
       
    }
            public static void displayThankYou()
    {
        System.out.print("---------------------------------------(displayThankyou Start)--------------------------------\n\n");
        
        System.out.print("Thank You ~ Have A Nice Day!\n\n");  
        
        System.out.print("=======================================(displayThankYou End)==================================\n\n");
    }
}
