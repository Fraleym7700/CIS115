package M_01_FraleyMichael;
import java.util.Scanner;
public class M_01_FraleyMichael
{
    public static void main(String[] args)
            
    {
     String name;
       
   
    Scanner keyboard = new Scanner(System.in);  
    System.out.println("Hello my name is Alexa, what is your name? : ");
    name = keyboard.nextLine();
    helloMessage(name);
    calculation();
    keyboard.nextLine();
    goodbyeMessage(name);
    }
    public static void helloMessage(String user)
    {
        String name;
        name = user;
        Scanner keyboard = new Scanner(System.in); 
        System.out.println("Hello " + name + " It is my pleasure to meet you this very day.");
        
    }
    public static void calculation()
    {
        int num1;
        int num2;
        int num3;
        int subtotal;
        int total;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("You will enter two numbers."
                + " Then you will choose a third number to subtract from the total. Press enter to start...");
       
        System.out.print(" ");
        keyboard.nextLine();
      
        System.out.print("Enter your first number ");
        num1 = keyboard.nextInt();
        
        System.out.print("Enter your second number: ");
        num2 = keyboard.nextInt();
        
        subtotal = (num1 + num2);
       
    
        System.out.print("Your subtotal is: " + subtotal + ". Press enter to continue: ");
        keyboard.nextLine();
        
        System.out.print(" ");
        keyboard.nextLine();
        
        System.out.print("Enter your third number: ");
        num3 = keyboard.nextInt();
        
        total = subtotal - num3;
        System.out.println("your total is: " + total);
        keyboard.nextLine();
    }
    public static void goodbyeMessage(String user)
    {
        String name;
        name = user;
        System.out.println("Goodbye " + name + " It is sad to see you go. Have a nice day!");

    }
}
