package nb_p2_fraleymichael;
import java.util.Scanner;
public class NB_P2_FraleyMichael 
{
    public static void main(String[] args)
    {
    /*The program should then display:
       The username
    The three (3) numbers entered
    The subtotal
    The total*/
        Scanner keyboard = new Scanner(System.in);
        String name;
        int num1;
        int num2;
        int num3;
        int subtotal;
        int total;
        
        System.out.print("You will enter your name and then two numbers."
                + " Then you will choose a third number to subtract from the total. Press enter to start...");
       
        System.out.print(" ");
        keyboard.nextLine();
        
        System.out.print("Enter your name: ");
        name = keyboard.nextLine();
        
        System.out.print("Enter your first number ");
        num1 = keyboard.nextInt();
        
        System.out.print("Enter your second number: ");
        num2 = keyboard.nextInt();
        
        subtotal = (num1 + num2);
       
    
        System.out.print("Your subtotal is: " + subtotal);
        keyboard.nextLine();
        
        System.out.print(" ");
        keyboard.nextLine();
        
        System.out.print("Enter your third number: ");
        num3 = keyboard.nextInt();
        
        total = subtotal - num3;
        System.out.print("your total is: " + total);
        
        
        
    }
}
