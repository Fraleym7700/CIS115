package m_02_fraleymichael;

import java.util.Scanner;

public class M_02_FraleyMichael
{
    public static void main(String[] args) 
    {
     int num1;
     int num2;
       
   
    Scanner keyboard = new Scanner(System.in);  
    System.out.println("Hello my name is Alexa, what two numbers would you like to use : ");
    num1 = keyboard.nextInt();
    num2 = keyboard.nextInt();
    addition(num1,num2);
    subtraction(num1,num2);
    division(num1,num2);
    multiplication(num1,num2);
    }
    public static void addition(int num1,int num2)
    {
    
        int totalSum;
        totalSum = num1 + num2;
        Scanner keyboard = new Scanner(System.in); 
        System.out.println(num1 + "+" + num2 + "=" + totalSum );
       
    }
    public static void subtraction(int num1,int num2)
    {
        int totalSum;
        totalSum = num1 - num2;
        Scanner keyboard = new Scanner(System.in); 
        System.out.println(num1 + "-" + num2 + "=" + totalSum );
        
    }
    public static void division(int num1, int num2)
    {

        int totalSum;
        totalSum = num1 / num2;
        Scanner keyboard = new Scanner(System.in); 
        System.out.println(num1 + "/" + num2 + "=" + totalSum );
        

    }
    public static void multiplication(int num1,int num2)
    {
    
        int totalSum;
        totalSum = num1 * num2;
        Scanner keyboard = new Scanner(System.in); 
        System.out.println(num1 + "*" + num2 + "=" + totalSum );
        
    }
    
}
