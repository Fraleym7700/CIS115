/*this program is made to find out the Land calculation of acres
psedocode:
Declasre thr tract sizes and acres;
Declare constant int sqFeetPerAcre
Display Enter the number of square feet in the tract
Input tractSize
set acrs = TractSize / SqFeetPerAcre
*/
package InClass_23_19111_FraleyMichael;
import java.util.Scanner;
public class InClass_23_19111_FraleyMichael {
    public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);
    final double SQ_FEET_PER_ACRE = 43560;
    System.out.print("How many Acres are there: ");
    
    double tractSize = myObj.nextDouble();
    double numberOfAcres = (tractSize/ SQ_FEET_PER_ACRE) * 1;
    
    System.out.print("Number of acres:" + numberOfAcres);
    }
    
}
