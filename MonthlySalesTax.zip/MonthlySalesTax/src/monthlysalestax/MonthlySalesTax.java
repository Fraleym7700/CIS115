package monthlysalestax;
import java.util.Scanner;
public class MonthlySalesTax {
        
public static void main(String[] args) {
    String userName = Greeting();
    Pseudocode();
    myMethod();
    thankYou(userName);
    
}
public static void thankYou(String x){
Scanner scanner = new Scanner(System.in);
System.out.print("~Thank you" + x + "for your participation, it ahs been a huge pleasure!~");
}
public static String Greeting(){
Scanner scanner = new Scanner(System.in);
System.out.print("Hello how are you, What is your name: ");
String userName = scanner.nextLine();
return userName;
} 

public static void Pseudocode(){
Scanner scanner = new Scanner(System.in);
System.out.print("\tPsedocode:\nI will first create the all the methods I need such as Greeting, Psuedocode, and Displaying the information\n"
        + "Purchase amount\n" +
"State sales tax\n" +
"Total sales tax\n" +
"Total Sale\n"
        + "\tPress enter to continue");
scanner.nextLine();
}

public static void myMethod(){
    final double STATE_TAX_PERCENTAGE = 0.04;
    final double COUNTY_TAX_PERCENTAGE = 0.02;
    double purchaseAmount;
    double countyTax;
    double stateTax;
    double totalTax;
    double totalSale;

    // creating a scanner objext
Scanner scanner = new Scanner(System.in);

System.out.println("Please enter the purchase amount:$ " );
purchaseAmount = scanner.nextDouble();

// Calculate the county tax
countyTax = COUNTY_TAX_PERCENTAGE * purchaseAmount;
// Calculate the state tax
stateTax = STATE_TAX_PERCENTAGE * purchaseAmount;
// Calculate the total tax
totalTax = stateTax + countyTax;
// Calculate the Total Sales
totalSale = totalTax + purchaseAmount; 
//Display details
System.out.println("------------------------------------------------------------------------------------------------------");
System.out.println("Purchase amount: " + purchaseAmount + "\nState sales tax: " + stateTax + "\nCounty Sales Tax: " +
                                countyTax + "\nTotal sales tax: " + totalTax + "\nTotal Sale: " + totalSale);
System.out.println("------------------------------------------------------------------------------------------------------");
System.out.println("------------------------------------------------------------------------------------------------------");








    }
    
}
