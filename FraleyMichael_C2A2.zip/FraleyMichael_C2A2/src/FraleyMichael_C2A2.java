import javax.swing.JOptionPane;
package fraleymichael_c2a2

public class FraleyMichael_C2A2 {
    
     public static int getNumberOfRooms(){
         String userInputString;
         int userNumberofRooms;
         userInputString = JOptionPane.showInputDialog("Please enter the number of rooms that are going to be painted: ");
         userNumberofRooms = Integer.parseInt(userInputString);
         return userNumberofRooms;
     } 
     public static double getPaintPrice(){
         String userInputString;
         double priceOfPaint;
         userInputString = JOptionPane.showInputDialog("Please enter the price of the paint: ");
         priceOfPaint = Double.parseDouble(userInputString);
         return priceOfPaint;
     }
     public static double getTotalWallSpace(int numberOfRooms ){
     double wallSpace; //wallspace
     double totalWallSpace = 0;
     for( int currentRoom = 1; currentRoom <= numberOfRooms; currentRoom++){
        wallSpace = JOptionPane.showInputDialog( "Please enter square feet of wall space in room: " + currentRoom );
         totalWallSpace += wallSpace;
        }
     return totalWallSpace;    
    }
     public static double calculateGallonsOfPaintsRequired(double totalWallSpace){
         /* if 115 square feet = 1 gallon
         thenn totalWallSpace = ?    
         */
         double gallonsOfPaintRequired;
         gallonsOfPaintRequired = (totalWallSpace /115) * 1;
         return gallonsOfPaintRequired;
     }
     public static double calculateHoursOfLaborRequired  (double totalWallSpace){
         /* if 115 square feet = 8 hours
         thenn 45 = ?    
         */
         double gallonsOfPaintRequired;
         gallonsOfPaintRequired = (totalWallSpace /115) * 1;
         return gallonsOfPaintRequired;
     }
     
     
    public static void main(String[] args) {
        
    }
    
}
